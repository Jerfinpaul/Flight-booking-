package com.example.admins;

public class Admins {

    public final static String SecretAdminCode = "admin";

}